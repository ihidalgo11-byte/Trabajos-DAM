package es.cide.programacio;
//Nombre: Iván Hidalgo Montalvo
//Fecha: 29/10/2025
import java.util.Scanner;
public class Examen1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int divisor = 1;
        int suma = 0;
        int numero = sc.nextInt();
        while (divisor != numero) {
            if (numero%divisor == 0) {
                suma = suma + divisor;
            }
            divisor++;
        }
        if (numero == suma) {
            System.out.println(numero+" és perfecte");
        } else if (numero != suma) {
            System.out.println(numero+" no és perfecte");
        }
    }
}