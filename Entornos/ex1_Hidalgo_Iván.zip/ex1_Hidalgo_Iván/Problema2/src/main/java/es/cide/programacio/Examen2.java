package es.cide.programacio;
//Nombre: Iván Hidalgo Montalvo
//Fecha: 29/10/2025
import java.util.Scanner;
public class Examen2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String numero = sc.next();
        int catidad = numero.length();
        int bucle = 0, resta = 1;
        while (bucle < catidad) {
            System.out.print(numero.charAt(catidad-resta));
            bucle++;
            resta++;
        }
    }
}