package es.cide.programacio;

public interface Speak {
    
    void sayHello();
    
    void sayGoodBye();
}
