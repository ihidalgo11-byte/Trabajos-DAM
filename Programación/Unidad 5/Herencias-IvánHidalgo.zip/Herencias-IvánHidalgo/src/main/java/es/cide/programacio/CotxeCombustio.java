package es.cide.programacio;

public class CotxeCombustio extends Coche {

    private int capacitatDiposit;
    private double preu;

    public CotxeCombustio(String matricula, String marca, int plaçes, int velocitatMax) {
        super(matricula, marca, plaçes, velocitatMax);
    }
    public CotxeCombustio(String matricula, String marca, int plaçes, int velocitatMax, int capacitatDiposit, int preu) {
        this(matricula, marca, plaçes, velocitatMax);
        this.capacitatDiposit = capacitatDiposit;
        this.preu = preu;
    }
    @Override
    public double calcularPreuLloguer(int dies) {
        return preu * dies;
    }
}
