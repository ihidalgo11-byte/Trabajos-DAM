package es.cide.programacio;

public class CotxeElectric extends Coche implements Recarregable {
    
    private double preu;
    private int bateria;

    public CotxeElectric(String matricula, String marca, int plaçes, int velocitatMax) {
        super(matricula, marca, plaçes, velocitatMax);
    }
    public CotxeElectric(String matricula, String marca, int plaçes, int velocitatMax, double preu, int bateria) {
        this(matricula, marca, plaçes, velocitatMax);
        this.preu = preu;
        this.bateria = bateria;
    }
    @Override
    public double calcularPreuLloguer(int dies) {
        return preu * dies;
    }
    @Override
    public int getNivellBateria() {
        return bateria;
    }
    public void carregarBateria(){

    }
}
