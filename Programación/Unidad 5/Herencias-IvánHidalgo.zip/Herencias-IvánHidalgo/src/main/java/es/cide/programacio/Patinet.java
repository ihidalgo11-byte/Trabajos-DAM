package es.cide.programacio;

public class Patinet extends Vehicle implements Recarregable {
    
    private double preu;
    private int bateria;

    public Patinet(String matricula, String marca) {
        super(matricula, marca);
    }

    public Patinet(String matricula, String marca, int preu, int bateria) {
        this(matricula, marca);
        this.preu = preu;
        this.bateria = bateria;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("=== FITXA PATINET ===");
        System.out.println("Marca del patinet: " + marca);
        System.out.println("Matrícula del patinet: " + matricula);
    }
    public void carregarBateria(){

    }
    @Override
    public int getNivellBateria() {
        return bateria;
    }
    @Override
    public double calcularPreuLloguer(int dies) {
        return preu * dies;
    }
} 
