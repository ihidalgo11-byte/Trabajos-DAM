package es.cide.programacio;

public interface Recarregable {
    public void carregarBateria();
    public int getNivellBateria();
}

